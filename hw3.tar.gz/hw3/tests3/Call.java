public class Call {

    static void f() {}

    public static void main (String[] args) {

	f();
    }
}

