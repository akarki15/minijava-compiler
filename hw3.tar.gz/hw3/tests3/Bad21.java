public class Bad21 {

    public static void main (String[] args) {

	int a;
	String s;
	int[] b;
	boolean bb;

	a = a*s;
	/*
	a = a-a;
	a = a%a;
	a = a*a;
	a = a/a;

	s = s + s;
	s = s + a;
	s = s + null;
	s = s + b;
	s = s + bb;
	*/

    }
}

