public class Loops {

    public static void main (String[] args) {

	if (true) int i;
	else int i;
	;
	while (true) int i;
	{
	    int i;
	    i = 4;
	}
    }
}
