public class Bad13 {

    public static void main (String[] args) {

	int[] a;
	int b;

	b = a["hi"];
    }
}

