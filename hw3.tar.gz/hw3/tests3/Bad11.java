public class Bad11 {

    public static void main (String[] args) {

	String s;

	if (s) {} else {}
    }
}
