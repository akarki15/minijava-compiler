public class Array {

    public static void main (String[] args) {

	int[] a;
	int b;

	b = a[3];
    }
}

