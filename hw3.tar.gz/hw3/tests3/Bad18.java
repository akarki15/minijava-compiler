public class Bad18 {

    public static void main (String[] args) {

	int[] i;

	i = new int["hi"];
    }
}

