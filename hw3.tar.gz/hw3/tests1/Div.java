public class Div {

    public static void main (String[] args) {

	System.out.print ("div yields " + (97 / 25) + "\n");	
	System.out.print ("mod yields " + (97 % 25) + "\n");

	int n;
	n = 25;

	System.out.print ("div yields " + (97 / n) + "\n");	
	System.out.print ("mod yields " + (97 % n) + "\n");
    }
}

