public class Bad3 {

    public static int a;

    public static void f (int a, int[][] b, String s) {;}

    public static int g()  { return 0; }

    public static String h (String i) { return "hi";}

    public static void f (int a, int b, String s) {return; }

    public static void b;
}
