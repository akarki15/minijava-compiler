public class Good17 {

    static void f(String s, int[] a) {}

    public static void main (String[] args) {

	f(null, null);
    }
}

