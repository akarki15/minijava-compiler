public class MakeArray {

    public static void main (String[] args) {

	int[] i;

	i = new int[13];
    }
}

