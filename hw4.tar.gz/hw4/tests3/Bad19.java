public class Bad19 {

    public static void main (String[] args) {

	int i;
	System.out.print(i.length());
    }
}

