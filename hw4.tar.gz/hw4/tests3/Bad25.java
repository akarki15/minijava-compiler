public class Bad25 {

    static void f() {
	return 3;    	
    }

    public static void main (String[] args) {
	f();
    }
}

