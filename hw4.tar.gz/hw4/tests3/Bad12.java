public class Bad12 {

    public static void main (String[] args) {

	int[] a;
	String b;

	b = a[3];
    }
}

