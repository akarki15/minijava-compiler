public class Foo {

    public static void main (String[] args) {

	System.out.print (true + "\n");
	System.out.print (false + "\n");	
	System.out.print (null + "\n");
	System.out.print (new int[3] + "\n");
    }
}
