package minijava.BackEnd.Assem;
import java.util.LinkedList;

public class InstrList extends LinkedList<Instr> {
}
