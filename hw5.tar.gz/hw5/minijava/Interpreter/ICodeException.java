package minijava.Interpreter;

public class ICodeException extends RuntimeException {

    public ICodeException (String s) {
	super(s);
    }
}
       