package minijava.Frame;

import minijava.Tree.Exp;

public abstract class Access {
    public abstract Exp exp (Exp framePtr);
}
