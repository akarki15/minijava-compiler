public class Bad20 {

    public static void main (String[] args) {

	int a;
	System.out.print(a.length);
    }
}

