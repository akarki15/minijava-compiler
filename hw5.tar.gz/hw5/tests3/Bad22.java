public class Bad22 {

    static void f() {}

    public static void main (String[] args) {

	System.out.print(f());
    }
}

