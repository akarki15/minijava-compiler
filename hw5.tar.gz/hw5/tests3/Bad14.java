public class Bad14 {

    public static void main (String[] args) {

	int a;
	int b;

	b = a[1];
    }
}

