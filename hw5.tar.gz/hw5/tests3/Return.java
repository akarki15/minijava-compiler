public class Return {

    static String f() {
	return null;
    }

    public static void main (String[] args) {
	System.out.print(f());
    }
}

