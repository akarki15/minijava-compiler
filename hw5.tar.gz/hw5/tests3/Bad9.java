public class Bad9 {

    public static void main (String[] args) {

	if (true) {

	    int i;
	    i = 3;

	}
	else {
	    int i;
	    i = 4;
	}

	System.out.print(i);
    }
}
