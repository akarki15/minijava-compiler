public class TwoBlocks {

    public static void main (String[] args) {

	if (true) {

	    int i;
	    i = 3;

	}
	else {
	    int i;
	    i = 4;
	}
    }
}
