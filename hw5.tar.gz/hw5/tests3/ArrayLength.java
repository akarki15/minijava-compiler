public class ArrayLength {

    public static void main (String[] args) {

	int[] a;
	System.out.print(a.length);
    }
}

