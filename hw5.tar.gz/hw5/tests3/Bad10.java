public class Bad10 {

    public static void main (String[] args) {

	while (1);
    }
}
