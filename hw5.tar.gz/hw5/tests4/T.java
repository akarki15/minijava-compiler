public class T {

    public static void main (String[] args) {    
    String s;    
	s = "Hello\n";	
	System.out.print(s);
    }
}
